//Quesada Iván, VINF014840 ,10/6/2024
package taller_algoritmo_estructura_datos.tp1_ivan_quesada;

public class Conteo {
    private String palabra;

    public Conteo(String palabra) {
        this.palabra = palabra.toUpperCase();
    }
    
    public int[] contarFrecuencia(){
    int[] conteos = new int[26];
    
    for (int i=0; i < palabra.length(); i++){
     //Comienzo try catch para capturar el error ArrayIndexOutOfBoundsException 
    try{
        conteos[palabra.charAt(i)-'A']++; 
    }catch(ArrayIndexOutOfBoundsException e){
        System.out.println("'" + palabra.charAt(i) + "' " + "No es un caracter valido ");
     } //Fin try catch para capturar el error ArrayIndexOutOfBoundsException 
    } 
    return conteos;
   } 
    public void imprimirFrecuencia (){
    int[] conteos = contarFrecuencia();
    System.out.println("\nFrecuencia de letras en la palabra " + palabra + ":");
    for (int i=0; i < conteos.length; i++) 
        if (conteos [i] != 0) 
        System.out.println((char)(i +'A') + ": " + conteos[i]);
    }
    
}
