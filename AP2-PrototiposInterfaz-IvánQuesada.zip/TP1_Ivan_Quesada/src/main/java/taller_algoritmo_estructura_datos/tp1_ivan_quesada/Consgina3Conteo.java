//Quesada Iván, VINF014840 ,10/6/2024
//Este código contara las letras de palabras con caracteres especiales, pero no tendra en cuenta los ultimos para la frecuencia de las letras.
package taller_algoritmo_estructura_datos.tp1_ivan_quesada;

import java.util.Scanner;


public class Consgina3Conteo {
    public static void main(String[] args) { 
        Scanner teclado = new Scanner(System.in);
        int n = 0;
        String opcion = "y";
        boolean entradacorrecta = false;
       
        while(!entradacorrecta){
        System.out.print("Ingrese la cantidad de palabras que desea almacenar: ");
        try{
        n = teclado.nextInt();
        entradacorrecta = true;
        if(n <= 0){
            System.out.println("La entrada debe ser mayor a cero.");
            entradacorrecta = false;
        }
        }catch (Exception InputMismatchExcception){
              System.out.println("La entrada debe ser un número.");
              teclado.next();
         }
        }
        teclado.nextLine();                         

        String[] palabras = new String[n];
        
        for (int i = 0; i < palabras.length; i++) {
            System.out.print("\nIngrese la palabra " + (i + 1) + ": ");
            palabras[i] = teclado.nextLine();
        }

        System.out.println("\nPalabras almacenadas: ");
        for (int i = 0; i < palabras.length; i++) {
            System.out.println((i + 1) + ": " + palabras[i]);
        }

         do{
            System.out.print("\nIngrese el número de la palabra que desea contar: ");
        try{
            int eleccion = teclado.nextInt();//Se lee la opción ingresada por el usuario, esperando un entero
            teclado.nextLine();


            if (eleccion > 0 && eleccion <= n) {
                Conteo conteo = new Conteo(palabras[eleccion - 1]);
                conteo.imprimirFrecuencia();
            }else {
                System.out.println("Número de elección no válido.");
             }
            }catch (Exception ex){
             System.out.println("Por favor, ingrese un número como elección.");
             teclado.nextLine();}//Fin try catch

           do {
                System.out.print("\n¿Desea seguir contando palabras? Y/N: ");
                opcion = teclado.nextLine().trim().toLowerCase();
                if (!opcion.equals("y") && !opcion.equals("n")) {
                    System.out.println("Entrada no válida. Por favor ingrese 'Y' o 'N'.");
                }
            } while (!opcion.equals("y") && !opcion.equals("n"));
        }while(opcion.equalsIgnoreCase("y"));
         System.out.println("\nPrograma finalizado");
    }
}
