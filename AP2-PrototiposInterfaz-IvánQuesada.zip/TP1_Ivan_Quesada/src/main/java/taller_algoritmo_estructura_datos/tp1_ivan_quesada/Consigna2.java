//Quesada Iván, VINF014840 ,10/6/2024
//Este código contara las letras de palabras con caracteres especiales, pero no tendra en cuenta los ultimos para la frecuencia de las letras.
package taller_algoritmo_estructura_datos.tp1_ivan_quesada;

import java.util.Scanner;

public class Consigna2 {
    public static void main(String[] args) {
     int[] conteos = new int[26]; 

    Scanner teclado = new Scanner(System.in);     

    //Leer palabra del usuario
    System.out.print("Ingrese una palabra (por favor, sólo letras): "); 
    String palabra = teclado.nextLine(); 
    
    //Convierte a mayusc. 
    palabra = palabra.toUpperCase(); 

    //Cuenta la frecuencia de cada letra...
    for (int i=0; i < palabra.length(); i++)
    //Comienzo try catch para capturar el error ArrayIndexOutOfBoundsException
    try{   
        
    conteos[palabra.charAt(i)-'A']++;
    
    }catch(ArrayIndexOutOfBoundsException e){
    System.out.println("\n'" + palabra.charAt(i) + "' No es un caracter valido ");} //Fin try catch para capturar el error ArrayIndexOutOfBoundsException
     
    //imprimir frecuencias...
    System.out.println(); 
    for (int i=0; i < conteos.length; i++) 

        if (conteos [i] != 0){ 
        System.out.println((char)(i +'A') + ": " + conteos[i]);}
    
    }//Fin main    
}//Fin clase Consigna2
